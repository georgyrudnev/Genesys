'use strict';

/**
 * Mock appointment availability for Video and Phone.
 *
 * DATE INTERPRETATION
 * - requestedDateText may contain:
 *   today
 *   tomorrow
 *   day after tomorrow
 *   weekday names
 *   next weekday names
 *   combined weekday requests, e.g.:
 *     "nächsten Montag oder Dienstag"
 *     "nächsten Montag oder nächsten Dienstag"
 *   this week
 *   next week
 *   week after next
 *   a specific DD.MM.YYYY date
 *   Saturday / Sunday
 *   blank = any available date
 *
 * AVAILABILITY RULES
 * - currentLocalDatetime is the source of truth for Germany local time.
 * - Earliest appointment = currentLocalDatetime + 1 hour.
 * - Latest appointment = currentLocalDatetime + 14 calendar days.
 * - Monday-Friday only.
 * - Appointment hours: 09:00-17:00.
 * - 30-minute appointment slots.
 * - Video and Phone have different deterministic availability.
 * - Maximum 3 results.
 *
 * RESULT BEHAVIOUR
 * - Specific single date:
 *     up to 3 appointments on that date.
 *
 * - Date range / period:
 *     up to 3 appointments on different dates.
 *
 * - Multiple explicitly requested dates:
 *     up to 3 appointments on the requested dates only.
 *
 * - Any time:
 *     up to 3 appointments on different dates,
 *     chronologically.
 */

exports.handler = async (event) => {
  console.log(
    'Mock availability request:',
    JSON.stringify(event)
  );

  try {
    const appointmentType = String(
      event?.appointmentType || ''
    ).trim();

    const currentLocalDatetime = String(
      event?.currentLocalDatetime || ''
    ).trim();

    const requestedDateText = String(
      event?.requestedDateText || ''
    ).trim();

    const requestedTime = String(
      event?.requestedTime || ''
    ).trim();

    // ----------------------------------------------------------
    // Validate appointment type
    // ----------------------------------------------------------

    if (!['Video', 'Phone'].includes(appointmentType)) {
      return buildError(
        'INPUT_001',
        'appointmentType must be Video or Phone'
      );
    }

    // ----------------------------------------------------------
    // Validate current local datetime
    // ----------------------------------------------------------

    if (!currentLocalDatetime) {
      return buildError(
        'INPUT_002',
        'currentLocalDatetime is required'
      );
    }

    const currentLocal = parseLocalIsoDatetime(
      currentLocalDatetime
    );

    if (!currentLocal) {
      return buildError(
        'INPUT_003',
        'Invalid currentLocalDatetime'
      );
    }

    // ----------------------------------------------------------
    // Parse requested time
    // ----------------------------------------------------------

    let requestedMinutes = null;

    if (requestedTime) {
      requestedMinutes =
        parseTimeToMinutes(
          requestedTime
        );

      if (requestedMinutes === null) {
        return buildError(
          'INPUT_004',
          'requestedTime must use HH:MM'
        );
      }
    }

    // ----------------------------------------------------------
    // Resolve requested date text
    // ----------------------------------------------------------

    const dateResolution =
      resolveRequestedDate(
        requestedDateText,
        currentLocal
      );

    if (!dateResolution.success) {
      return buildError(
        'INPUT_005',
        dateResolution.errorMessage
      );
    }

    // ----------------------------------------------------------
    // Generate complete valid availability
    // ----------------------------------------------------------

    const allSlots = generateSlots(
      currentLocal,
      appointmentType
    );

    // ----------------------------------------------------------
    // Apply resolved date range or explicit date list
    // ----------------------------------------------------------

    let matchingSlots = allSlots;

    /*
     * Explicit multiple dates take priority.
     *
     * Example:
     * "nächsten Montag oder Dienstag"
     *
     * Only the explicitly resolved dates are allowed.
     */
    if (
      Array.isArray(dateResolution.dateList) &&
      dateResolution.dateList.length > 0
    ) {
      matchingSlots =
        matchingSlots.filter(
          (slot) => {
            const slotDate =
              parseGermanDate(
                slot.appointmentDate
              );

            return dateResolution.dateList.some(
              requestedDate =>
                compareDates(
                  slotDate,
                  requestedDate
                ) === 0
            );
          }
        );
    } else if (
      dateResolution.dateFrom &&
      dateResolution.dateTo
    ) {
      matchingSlots =
        matchingSlots.filter(
          (slot) => {
            const slotDate =
              parseGermanDate(
                slot.appointmentDate
              );

            return (
              compareDates(
                slotDate,
                dateResolution.dateFrom
              ) >= 0 &&
              compareDates(
                slotDate,
                dateResolution.dateTo
              ) <= 0
            );
          }
        );
    }

    // ----------------------------------------------------------
    // Determine single-date vs multi-date search
    // ----------------------------------------------------------

    const isSingleDateSearch =
      !Array.isArray(dateResolution.dateList) ||
      dateResolution.dateList.length === 0
        ? (
            dateResolution.dateFrom &&
            dateResolution.dateTo &&
            compareDates(
              dateResolution.dateFrom,
              dateResolution.dateTo
            ) === 0
          )
        : dateResolution.dateList.length === 1;

    // ----------------------------------------------------------
    // Select results
    // ----------------------------------------------------------

    let selectedSlots;

    if (isSingleDateSearch) {
      selectedSlots =
        selectSingleDateResults(
          matchingSlots,
          requestedMinutes
        );
    } else {
      selectedSlots =
        selectMultiDateResults(
          matchingSlots,
          requestedMinutes
        );
    }

    // ----------------------------------------------------------
    // Return result
    // ----------------------------------------------------------

    return {
      success: true,
      appointmentType,
      resultCount: selectedSlots.length,
      errorCode: '',
      errorMessage: '',

      appointmentDate:
        selectedSlots.map(
          slot => slot.appointmentDate
        ),

      appointmentWeekday:
        selectedSlots.map(
          slot => slot.appointmentWeekday
        ),

      appointmentStartTime:
        selectedSlots.map(
          slot => slot.appointmentStartTime
        ),

      appointmentEndTime:
        selectedSlots.map(
          slot => slot.appointmentEndTime
        ),

      appointmentOffice:
        selectedSlots.map(
          slot => slot.appointmentOffice
        ),

      terminvorschlagId:
        selectedSlots.map(
          slot => slot.terminvorschlagId
        )
    };

  } catch (error) {
    console.error(
      'Mock availability error:',
      error
    );

    return buildError(
      'ERROR_999',
      'Unexpected error'
    );
  }
};


/**
 * Resolve customer date expressions into a date range
 * or an explicit list of dates.
 */
function resolveRequestedDate(
  requestedDateText,
  currentLocal
) {
  const text =
    normaliseDateText(
      requestedDateText
    );

  /*
   * Blank date = search complete valid window.
   */
  if (!text) {
    return {
      success: true,
      dateFrom: null,
      dateTo: null,
      dateList: []
    };
  }

  /*
   * Specific DD.MM.YYYY date.
   */
  const explicitDate =
    parseGermanDate(text);

  if (explicitDate) {
    return {
      success: true,
      dateFrom: explicitDate,
      dateTo: { ...explicitDate },
      dateList: [explicitDate]
    };
  }

  const today =
    dateObjectFromLocal(
      currentLocal
    );

  /*
   * Combined next-weekday request.
   *
   * Examples:
   * "nächsten Montag oder Dienstag"
   * "nächsten Montag oder nächsten Dienstag"
   * "next Monday or Tuesday"
   * "next Monday or next Tuesday"
   *
   * Resolve each weekday independently so that
   * only the requested dates are considered.
   */
  const combinedNextWeekdays =
    getCombinedNextWeekdays(
      text,
      today
    );

  if (
    combinedNextWeekdays !== null
  ) {
    return {
      success: true,
      dateFrom: null,
      dateTo: null,
      dateList:
        combinedNextWeekdays
    };
  }

  /*
   * TODAY
   */
  if (
    text === 'today' ||
    text === 'heute'
  ) {
    return {
      success: true,
      dateFrom: today,
      dateTo: { ...today },
      dateList: [today]
    };
  }

  /*
   * TOMORROW
   */
  if (
    text === 'tomorrow' ||
    text === 'morgen'
  ) {
    const tomorrow =
      addDays(
        today,
        1
      );

    return {
      success: true,
      dateFrom: tomorrow,
      dateTo: { ...tomorrow },
      dateList: [tomorrow]
    };
  }

  /*
   * DAY AFTER TOMORROW
   */
  if (
    text === 'day after tomorrow' ||
    text === 'übermorgen'
  ) {
    const dayAfterTomorrow =
      addDays(
        today,
        2
      );

    return {
      success: true,
      dateFrom: dayAfterTomorrow,
      dateTo: { ...dayAfterTomorrow },
      dateList: [dayAfterTomorrow]
    };
  }

  /*
   * THIS WEEK
   *
   * Monday-Sunday of the current calendar week.
   * Availability later removes weekends.
   */
  if (
    text === 'this week' ||
    text === 'diese woche'
  ) {
    const monday =
      startOfWeek(
        today
      );

    const sunday =
      addDays(
        monday,
        6
      );

    return {
      success: true,
      dateFrom: monday,
      dateTo: sunday,
      dateList: []
    };
  }

  /*
   * NEXT WEEK
   *
   * Monday-Sunday of the next calendar week.
   */
  if (
    text === 'next week' ||
    text === 'nächste woche'
  ) {
    const currentMonday =
      startOfWeek(
        today
      );

    const nextMonday =
      addDays(
        currentMonday,
        7
      );

    const nextSunday =
      addDays(
        nextMonday,
        6
      );

    return {
      success: true,
      dateFrom: nextMonday,
      dateTo: nextSunday,
      dateList: []
    };
  }

  /*
   * WEEK AFTER NEXT
   */
  if (
    text === 'week after next' ||
    text === 'übernächste woche'
  ) {
    const currentMonday =
      startOfWeek(
        today
      );

    const weekAfterNextMonday =
      addDays(
        currentMonday,
        14
      );

    const weekAfterNextSunday =
      addDays(
        weekAfterNextMonday,
        6
      );

    return {
      success: true,
      dateFrom:
        weekAfterNextMonday,
      dateTo:
        weekAfterNextSunday,
      dateList: []
    };
  }

  /*
   * NEXT WEEKDAY
   *
   * Example:
   * "next Friday"
   * "nächsten Freitag"
   *
   * Always means the weekday in the next
   * calendar week.
   */
  const nextWeekday =
    getWeekdayFromNextPhrase(
      text
    );

  if (nextWeekday !== null) {
    const currentMonday =
      startOfWeek(
        today
      );

    const nextMonday =
      addDays(
        currentMonday,
        7
      );

    const resolved =
      addDays(
        nextMonday,
        nextWeekday - 1
      );

    return {
      success: true,
      dateFrom: resolved,
      dateTo: { ...resolved },
      dateList: [resolved]
    };
  }

  /*
   * Plain weekday.
   *
   * Example:
   * "Wednesday"
   * "Mittwoch"
   *
   * If today is that weekday, today is allowed.
   * Otherwise use the next occurrence.
   */
  const weekday =
    getWeekday(
      text
    );

  if (weekday !== null) {
    const currentWeekday =
      todayWeekday(
        today
      );

    let daysAhead =
      weekday -
      currentWeekday;

    if (daysAhead < 0) {
      daysAhead += 7;
    }

    const resolved =
      addDays(
        today,
        daysAhead
      );

    return {
      success: true,
      dateFrom: resolved,
      dateTo: { ...resolved },
      dateList: [resolved]
    };
  }

  /*
   * Explicit weekend request.
   *
   * We intentionally resolve Saturday/Sunday here.
   * The availability generator will then return zero slots.
   */
  if (
    text === 'weekend' ||
    text === 'wochenende'
  ) {
    const currentWeekday =
      todayWeekday(
        today
      );

    let daysToSaturday =
      6 -
      currentWeekday;

    if (daysToSaturday < 0) {
      daysToSaturday += 7;
    }

    const saturday =
      addDays(
        today,
        daysToSaturday
      );

    const sunday =
      addDays(
        saturday,
        1
      );

    return {
      success: true,
      dateFrom: saturday,
      dateTo: sunday,
      dateList: []
    };
  }

  return {
    success: false,
    errorMessage:
      'Unsupported requestedDateText'
  };
}


/**
 * Resolve combined "next weekday or weekday" requests.
 *
 * Supported examples:
 * - nächsten Montag oder Dienstag
 * - nächsten Montag oder nächsten Dienstag
 * - next Monday or Tuesday
 * - next Monday or next Tuesday
 *
 * Returns an array containing the exact calendar dates requested.
 */
function getCombinedNextWeekdays(
  text,
  today
) {
  const match =
    /^(?:next|n[aä]chsten?|n[aä]chste)\s+(.+?)\s+oder\s+(?:(?:next|n[aä]chsten?|n[aä]chste)\s+)?(.+)$/
      .exec(text);

  if (!match) {
    return null;
  }

  const firstWeekday =
    getWeekday(
      match[1]
    );

  const secondWeekday =
    getWeekday(
      match[2]
    );

  if (
    firstWeekday === null ||
    secondWeekday === null
  ) {
    return null;
  }

  const currentMonday =
    startOfWeek(
      today
    );

  const nextMonday =
    addDays(
      currentMonday,
      7
    );

  const firstDate =
    addDays(
      nextMonday,
      firstWeekday - 1
    );

  const secondDate =
    addDays(
      nextMonday,
      secondWeekday - 1
    );

  const dates = [
    firstDate,
    secondDate
  ];

  /*
   * Remove duplicates while preserving
   * chronological order.
   */
  dates.sort(
    compareDates
  );

  return dates.filter(
    (date, index) => {
      if (index === 0) {
        return true;
      }

      return (
        compareDates(
          date,
          dates[index - 1]
        ) !== 0
      );
    }
  );
}


/**
 * Normalise text for date phrase matching.
 */
function normaliseDateText(
  value
) {
  return String(
    value || ''
  )
    .trim()
    .toLowerCase()
    .replace(/\s+/g, ' ');
}


/**
 * Resolve "next Monday", "next Friday", etc.
 */
function getWeekdayFromNextPhrase(
  text
) {
  const match =
    /^(?:next|n[aä]chsten?|n[aä]chste)\s+(.+)$/
      .exec(text);

  if (!match) {
    return null;
  }

  return getWeekday(
    match[1]
  );
}


/**
 * Monday = 1 ... Sunday = 7.
 */
function getWeekday(
  text
) {
  const mapping = {
    monday: 1,
    montag: 1,

    tuesday: 2,
    dienstag: 2,

    wednesday: 3,
    mittwoch: 3,

    thursday: 4,
    donnerstag: 4,

    friday: 5,
    freitag: 5,

    saturday: 6,
    samstag: 6,

    sunday: 7,
    sonntag: 7
  };

  return Object.prototype.hasOwnProperty.call(
    mapping,
    text
  )
    ? mapping[text]
    : null;
}


/**
 * Return current local weekday.
 */
function todayWeekday(
  date
) {
  const jsDay =
    new Date(
      Date.UTC(
        date.year,
        date.month - 1,
        date.day
      )
    ).getUTCDay();

  return jsDay === 0
    ? 7
    : jsDay;
}


/**
 * Convert local components to a neutral date object.
 */
function dateObjectFromLocal(
  local
) {
  return {
    day: local.day,
    month: local.month,
    year: local.year
  };
}


/**
 * Add whole calendar days.
 */
function addDays(
  date,
  numberOfDays
) {
  const value =
    new Date(
      Date.UTC(
        date.year,
        date.month - 1,
        date.day
      )
    );

  value.setUTCDate(
    value.getUTCDate() +
    numberOfDays
  );

  return {
    day:
      value.getUTCDate(),

    month:
      value.getUTCMonth() + 1,

    year:
      value.getUTCFullYear()
  };
}


/**
 * Monday of the calendar week.
 */
function startOfWeek(
  date
) {
  const weekday =
    todayWeekday(
      date
    );

  return addDays(
    date,
    -(weekday - 1)
  );
}


/**
 * Specific-date selection.
 *
 * If a time is requested:
 *   return 3 closest times.
 *
 * Otherwise:
 *   return first 3 chronologically.
 */
function selectSingleDateResults(
  slots,
  requestedMinutes
) {
  const sorted =
    [...slots];

  if (
    requestedMinutes !== null
  ) {
    sorted.sort(
      (a, b) => {
        const aDiff =
          Math.abs(
            timeToMinutes(
              a.appointmentStartTime
            ) -
            requestedMinutes
          );

        const bDiff =
          Math.abs(
            timeToMinutes(
              b.appointmentStartTime
            ) -
            requestedMinutes
          );

        if (aDiff !== bDiff) {
          return aDiff - bDiff;
        }

        return a.appointmentStartTime.localeCompare(
          b.appointmentStartTime
        );
      }
    );
  } else {
    sorted.sort(
      compareSlotsChronologically
    );
  }

  return sorted.slice(
    0,
    3
  );
}


/**
 * Multi-date selection.
 *
 * Returns maximum one appointment per date.
 */
function selectMultiDateResults(
  slots,
  requestedMinutes
) {
  const grouped =
    groupSlotsByDate(
      slots
    );

  const dayCandidates = [];

  for (
    const [date, daySlots]
    of grouped.entries()
  ) {
    const sortedDaySlots =
      [...daySlots];

    if (
      requestedMinutes !== null
    ) {
      sortedDaySlots.sort(
        (a, b) => {
          const aDiff =
            Math.abs(
              timeToMinutes(
                a.appointmentStartTime
              ) -
              requestedMinutes
            );

          const bDiff =
            Math.abs(
              timeToMinutes(
                b.appointmentStartTime
              ) -
              requestedMinutes
            );

          if (aDiff !== bDiff) {
            return aDiff - bDiff;
          }

          return a.appointmentStartTime.localeCompare(
            b.appointmentStartTime
          );
        }
      );
    } else {
      sortedDaySlots.sort(
        compareSlotsChronologically
      );
    }

    if (
      sortedDaySlots.length > 0
    ) {
      const best =
        sortedDaySlots[0];

      const timeDifference =
        requestedMinutes !== null
          ? Math.abs(
              timeToMinutes(
                best.appointmentStartTime
              ) -
              requestedMinutes
            )
          : null;

      dayCandidates.push({
        date,
        bestSlot: best,
        timeDifference
      });
    }
  }

  /*
   * With a requested time:
   * choose the three dates whose best
   * appointment is closest to that time.
   *
   * Without a requested time:
   * choose the earliest dates first.
   */
  if (
    requestedMinutes !== null
  ) {
    dayCandidates.sort(
      (a, b) => {
        if (
          a.timeDifference !==
          b.timeDifference
        ) {
          return (
            a.timeDifference -
            b.timeDifference
          );
        }

        return compareGermanDateStrings(
          a.date,
          b.date
        );
      }
    );
  } else {
    dayCandidates.sort(
      (a, b) =>
        compareGermanDateStrings(
          a.date,
          b.date
        )
    );
  }

  return dayCandidates
    .slice(
      0,
      3
    )
    .map(
      candidate =>
        candidate.bestSlot
    );
}


/**
 * Group appointments by date.
 */
function groupSlotsByDate(
  slots
) {
  const grouped =
    new Map();

  for (
    const slot of slots
  ) {
    if (
      !grouped.has(
        slot.appointmentDate
      )
    ) {
      grouped.set(
        slot.appointmentDate,
        []
      );
    }

    grouped
      .get(
        slot.appointmentDate
      )
      .push(slot);
  }

  return grouped;
}


/**
 * Generate all valid appointment slots.
 *
 * Earliest:
 *   currentLocalDatetime + 1 hour
 *
 * Latest:
 *   currentLocalDatetime + 14 days
 */
function generateSlots(
  currentLocal,
  appointmentType
) {
  const slots = [];

  const currentWallClockMs =
    Date.UTC(
      currentLocal.year,
      currentLocal.month - 1,
      currentLocal.day,
      currentLocal.hour,
      currentLocal.minute,
      currentLocal.second
    );

  const earliestMs =
    currentWallClockMs +
    (60 * 60 * 1000);

  const latestMs =
    currentWallClockMs +
    (
      14 *
      24 *
      60 *
      60 *
      1000
    );

  const startDayMs =
    Date.UTC(
      currentLocal.year,
      currentLocal.month - 1,
      currentLocal.day,
      0,
      0,
      0
    );

  for (
    let dayOffset = 0;
    dayOffset <= 14;
    dayOffset++
  ) {
    const dayMs =
      startDayMs +
      (
        dayOffset *
        24 *
        60 *
        60 *
        1000
      );

    const calendarDate =
      new Date(
        dayMs
      );

    const weekday =
      calendarDate.getUTCDay();

    /*
     * Monday-Friday only.
     */
    if (
      weekday === 0 ||
      weekday === 6
    ) {
      continue;
    }

    for (
      let hour = 9;
      hour < 17;
      hour++
    ) {
      for (
        const minute of [0, 30]
      ) {
        const slotStartMs =
          Date.UTC(
            calendarDate.getUTCFullYear(),
            calendarDate.getUTCMonth(),
            calendarDate.getUTCDate(),
            hour,
            minute,
            0
          );

        /*
         * Must be at least one hour in future.
         */
        if (
          slotStartMs <
          earliestMs
        ) {
          continue;
        }

        /*
         * Must be inside 14-day boundary.
         */
        if (
          slotStartMs >
          latestMs
        ) {
          continue;
        }

        /*
         * Some slots deliberately unavailable.
         */
        if (
          isUnavailable(
            appointmentType,
            dayOffset,
            hour,
            minute
          )
        ) {
          continue;
        }

        const slotEndMs =
          slotStartMs +
          (
            30 *
            60 *
            1000
          );

        const slotStart =
          new Date(
            slotStartMs
          );

        const slotEnd =
          new Date(
            slotEndMs
          );

        slots.push({
          appointmentDate:
            formatUtcDate(
              slotStart
            ),

          appointmentWeekday:
            getGermanWeekdayFromDate(
              slotStart
            ),

          appointmentStartTime:
            formatUtcTime(
              slotStart
            ),

          appointmentEndTime:
            formatUtcTime(
              slotEnd
            ),

          appointmentOffice:
            appointmentType,

          terminvorschlagId:
            buildMockId(
              appointmentType,
              slotStart
            )
        });
      }
    }
  }

  return slots;
}


/**
 * Deterministic unavailable-slot patterns.
 *
 * Video and Phone intentionally differ.
 */
function isUnavailable(
  appointmentType,
  dayOffset,
  hour,
  minute
) {
  const slotIndex =
    (
      (hour - 9) *
      2
    ) +
    (
      minute === 30
        ? 1
        : 0
    );

  if (
    appointmentType === 'Video'
  ) {
    return (
      (
        dayOffset % 2 === 0 &&
        slotIndex % 5 === 0
      ) ||
      (
        dayOffset % 3 === 0 &&
        hour === 13 &&
        minute === 0
      ) ||
      (
        dayOffset % 4 === 0 &&
        hour === 15 &&
        minute === 30
      )
    );
  }

  /*
   * Phone
   */
  return (
    (
      dayOffset % 2 === 1 &&
      slotIndex % 4 === 0
    ) ||
    (
      dayOffset % 3 === 1 &&
      hour === 11 &&
      minute === 30
    ) ||
    (
      dayOffset % 4 === 2 &&
      hour === 14 &&
      minute === 0
    )
  );
}


/**
 * Deterministic mock appointment ID.
 */
function buildMockId(
  appointmentType,
  date
) {
  const prefix =
    appointmentType === 'Video'
      ? 'MOCK-VIDEO'
      : 'MOCK-PHONE';

  const yyyy =
    date.getUTCFullYear();

  const mm =
    String(
      date.getUTCMonth() + 1
    ).padStart(
      2,
      '0'
    );

  const dd =
    String(
      date.getUTCDate()
    ).padStart(
      2,
      '0'
    );

  const hh =
    String(
      date.getUTCHours()
    ).padStart(
      2,
      '0'
    );

  const min =
    String(
      date.getUTCMinutes()
    ).padStart(
      2,
      '0'
    );

  return (
    `${prefix}-${yyyy}${mm}${dd}-${hh}${min}`
  );
}


/**
 * Parse currentLocalDatetime while preserving the
 * Germany-local wall-clock components.
 */
function parseLocalIsoDatetime(
  value
) {
  const match =
    /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})(?::(\d{2}))?(?:[+-]\d{2}:\d{2}|Z)$/
      .exec(value);

  if (!match) {
    return null;
  }

  const result = {
    year: Number(match[1]),
    month: Number(match[2]),
    day: Number(match[3]),
    hour: Number(match[4]),
    minute: Number(match[5]),
    second: Number(match[6] || 0)
  };

  if (
    result.month < 1 ||
    result.month > 12 ||
    result.hour < 0 ||
    result.hour > 23 ||
    result.minute < 0 ||
    result.minute > 59 ||
    result.second < 0 ||
    result.second > 59
  ) {
    return null;
  }

  const validationDate =
    new Date(
      Date.UTC(
        result.year,
        result.month - 1,
        result.day
      )
    );

  if (
    validationDate.getUTCFullYear() !==
      result.year ||
    validationDate.getUTCMonth() + 1 !==
      result.month ||
    validationDate.getUTCDate() !==
      result.day
  ) {
    return null;
  }

  return result;
}


/**
 * Parse DD.MM.YYYY.
 */
function parseGermanDate(
  value
) {
  const match =
    /^(\d{2})\.(\d{2})\.(\d{4})$/
      .exec(value);

  if (!match) {
    return null;
  }

  const result = {
    day: Number(match[1]),
    month: Number(match[2]),
    year: Number(match[3])
  };

  const validationDate =
    new Date(
      Date.UTC(
        result.year,
        result.month - 1,
        result.day
      )
    );

  if (
    validationDate.getUTCFullYear() !==
      result.year ||
    validationDate.getUTCMonth() + 1 !==
      result.month ||
    validationDate.getUTCDate() !==
      result.day
  ) {
    return null;
  }

  return result;
}


function compareDates(
  a,
  b
) {
  const aValue =
    (
      a.year * 10000
    ) +
    (
      a.month * 100
    ) +
    a.day;

  const bValue =
    (
      b.year * 10000
    ) +
    (
      b.month * 100
    ) +
    b.day;

  return (
    aValue - bValue
  );
}


function compareGermanDateStrings(
  a,
  b
) {
  return compareDates(
    parseGermanDate(a),
    parseGermanDate(b)
  );
}


function compareSlotsChronologically(
  a,
  b
) {
  const dateCompare =
    compareGermanDateStrings(
      a.appointmentDate,
      b.appointmentDate
    );

  if (
    dateCompare !== 0
  ) {
    return dateCompare;
  }

  return a.appointmentStartTime.localeCompare(
    b.appointmentStartTime
  );
}


/**
 * Parse HH:MM.
 */
function parseTimeToMinutes(
  value
) {
  const match =
    /^(\d{2}):(\d{2})$/
      .exec(value);

  if (!match) {
    return null;
  }

  const hour =
    Number(match[1]);

  const minute =
    Number(match[2]);

  if (
    hour < 0 ||
    hour > 23 ||
    minute < 0 ||
    minute > 59
  ) {
    return null;
  }

  return (
    (
      hour * 60
    ) +
    minute
  );
}


function timeToMinutes(
  value
) {
  const [
    hour,
    minute
  ] =
    value
      .split(':')
      .map(Number);

  return (
    (
      hour * 60
    ) +
    minute
  );
}


function formatUtcDate(
  date
) {
  const day =
    String(
      date.getUTCDate()
    ).padStart(
      2,
      '0'
    );

  const month =
    String(
      date.getUTCMonth() + 1
    ).padStart(
      2,
      '0'
    );

  const year =
    date.getUTCFullYear();

  return (
    `${day}.${month}.${year}`
  );
}


/**
 * Return the German weekday for the exact
 * appointment calendar date.
 *
 * This is deliberately calculated in the Lambda,
 * not by the AVA, so the date and weekday come
 * from the same calendar value.
 */
function getGermanWeekdayFromDate(
  date
) {
  const weekdays = [
    'Sonntag',
    'Montag',
    'Dienstag',
    'Mittwoch',
    'Donnerstag',
    'Freitag',
    'Samstag'
  ];

  return weekdays[
    date.getUTCDay()
  ];
}


function formatUtcTime(
  date
) {
  const hour =
    String(
      date.getUTCHours()
    ).padStart(
      2,
      '0'
    );

  const minute =
    String(
      date.getUTCMinutes()
    ).padStart(
      2,
      '0'
    );

  return (
    `${hour}:${minute}`
  );
}


function buildError(
  errorCode,
  errorMessage
) {
  return {
    success: false,
    appointmentType: '',
    resultCount: 0,
    errorCode,
    errorMessage,
    appointmentDate: [],
    appointmentWeekday: [],
    appointmentStartTime: [],
    appointmentEndTime: [],
    appointmentOffice: [],
    terminvorschlagId: []
  };
}