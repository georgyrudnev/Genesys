'use strict';

/**
 * Finalises a selected mock Video or Phone appointment.
 *
 * Inputs:
 * - appointmentType
 * - appointmentDate
 * - appointmentTime
 * - terminvorschlagId
 *
 * Returns the single confirmed appointment for Architect.
 */

exports.handler = async (event) => {
  console.log(
    'Mock appointment finalisation request:',
    JSON.stringify(event)
  );

  try {
    const appointmentType = String(
      event?.appointmentType || ''
    ).trim();

    const appointmentDate = String(
      event?.appointmentDate || ''
    ).trim();

    const appointmentTime = String(
      event?.appointmentTime || ''
    ).trim();

    const terminvorschlagId = String(
      event?.terminvorschlagId || ''
    ).trim();

    if (
      !['Video', 'Phone'].includes(
        appointmentType
      )
    ) {
      return {
        success: false,
        errorCode: 'INPUT_001',
        errorMessage:
          'appointmentType must be Video or Phone'
      };
    }

    if (!appointmentDate) {
      return {
        success: false,
        errorCode: 'INPUT_002',
        errorMessage:
          'appointmentDate is required'
      };
    }

    if (!appointmentTime) {
      return {
        success: false,
        errorCode: 'INPUT_003',
        errorMessage:
          'appointmentTime is required'
      };
    }

    if (!terminvorschlagId) {
      return {
        success: false,
        errorCode: 'INPUT_004',
        errorMessage:
          'terminvorschlagId is required'
      };
    }

    return {
      success: true,
      errorCode: '',
      errorMessage: '',
      appointment_type: appointmentType,
      appointment_datetime:
        `${appointmentDate} ${appointmentTime}`,
      terminvorschlag_id:
        terminvorschlagId,
      appointment_duration: 30
    };

  } catch (error) {
    console.error(
      'Mock appointment finalisation error:',
      error
    );

    return {
      success: false,
      errorCode: 'ERROR_999',
      errorMessage:
        'Unexpected error'
    };
  }
};