"use strict";

const crypto = require('crypto');

const createLog = (level, message, details = {}) =>
  console.log(JSON.stringify({ level, message, ...details, timestamp: new Date().toISOString() }));

exports.handler = async (event) => {
  const invocationId = crypto.randomUUID();
  try {
    const { InputValue } = event;

    if (InputValue === undefined || InputValue === null || typeof InputValue !== "string") {
      createLog("warn", "Missing or invalid required field: InputValue", { invocationId });
      return { status: 400, error: "Missing required field: InputValue" };
    }

    createLog("info", "Pass-through execution", { invocationId, InputValue });

    return {
      status: 200,
      OutputValue: InputValue
    };
  } catch (err) {
    createLog("error", "Unhandled error", { invocationId, message: err.message });
    return { status: 500, error: "Internal server error" };
  }
};
