# AVA Tool Config - SetAVAOutput

## Tool Metadata

**Tool - Name:** SetAVAOutput

**Tool - Description:** Pass-through function that returns the input string as the output value

## Input Configuration

**Input - Pre-instructions:** Use this tool only after the agent has collected and validated every required input value from the customer or conversation context. Do not guess required values.

### Input element 1

**Input element 1 - Name:** InputValue
**Input element 1 - Description:** The string value to pass through. This value will be returned unchanged as OutputValue.
**Input element 1 - Type:** None

## Output Configuration

**Output - Outcome Instructions:** If the tool returns a `status` field of 400 or 500 with an `error`, explain the issue briefly and collect corrected inputs or escalate according to the conversation design. For successful responses, summarize the relevant returned data in customer-friendly language.

**Output - general output name:** functionResult
**Output - general output description:** Complete response object returned by the SetAVAOutput simulated web-service function.

_No output objects below the parent element._
