# SetAVAOutput deployment

Generated at 2026-07-27T07:54:45.443Z.

## Generated assets

- Function folder: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput`
- Zip to upload: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/function.zip`
- Source file: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/src/index.js`
- Input contract file: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/input-contract.json`
- Output contract file: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/output-contract.json`
- Response configuration file: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/response-config.json`
- Genesys output validation report: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/genesys-data-action-validation.json`
- Sample input file: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/sample-input.json`
- Sample output file: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/sample-output.json`
- AVA tool config: `/sessions/friendly-magical-planck/mnt/outputs/GC_Functions/SetAVAOutput/ava-tool-config.md`

## Genesys Cloud Function Data Action deployment

1. Ensure you have at least one active Function Data Actions integration in Genesys Cloud; create the new action there.
2. Claude Cowork has already created the deployment assets. Do not create a folder, create files, or zip anything manually.
3. In the Function Data Action tab set:
   - Handler: `src/index.handler`
   - Runtime: `nodejs22.x`
   - Upload: select the generated `function.zip` from the path above.
4. In the Contracts tab, switch to JSON mode and use the generated contract files:
   - Input contract file: `input-contract.json`
   - Output contract file: `output-contract.json`
5. In the Response configuration / Output transformation area, keep the no-op raw-result configuration. If the UI asks for explicit values, use `response-config.json`:
   - Translation map: `{}`
   - Translation map defaults: `{}`
   - Success template: `${rawResult}`
6. Review `genesys-data-action-validation.json`, then test with representative inputs and keep Flatten output selected. The report must show passed operations for Resolve translation map, Apply output transformation, Validate output against schema, Validate output schema can be flattened, and Flatten.
7. If errors occur in Genesys Cloud, capture the inputs used and the External execution log section.
