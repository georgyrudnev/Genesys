'use strict';

/**
 * Finalises an unsuccessful mock Video or Phone
 * appointment journey.
 *
 * Intended for cases such as:
 * - Customer no longer wants an appointment
 * - Customer rejects the available appointments
 *   and does not want further alternatives
 *
 * Inputs:
 * - appointmentType: "Video" | "Phone"
 * - reason
 *
 * Output:
 * - success
 * - outcome
 * - appointment_type
 * - reason
 * - errorCode
 * - errorMessage
 */

exports.handler = async (event) => {
  console.log(
    'Mock unsuccessful finalisation request:',
    JSON.stringify(event)
  );

  try {
    const appointmentType = String(
      event?.appointmentType || ''
    ).trim();

    const reason = String(
      event?.reason || ''
    ).trim();

    // Validate appointment type.
    if (!['Video', 'Phone'].includes(appointmentType)) {
      return {
        success: false,
        outcome: '',
        appointment_type: '',
        reason,
        errorCode: 'INPUT_001',
        errorMessage:
          'appointmentType must be Video or Phone'
      };
    }

    // Validate reason.
    const allowedReasons = [
      'CUSTOMER_DECLINED_APPOINTMENT',
      'CUSTOMER_CANCELLED_JOURNEY',
      'NO_SUITABLE_APPOINTMENT'
    ];

    if (!allowedReasons.includes(reason)) {
      return {
        success: false,
        outcome: '',
        appointment_type: appointmentType,
        reason,
        errorCode: 'INPUT_002',
        errorMessage: 'Invalid or missing reason'
      };
    }

    return {
      success: true,
      outcome: 'UNSUCCESSFUL_FINALIZED',
      appointment_type: appointmentType,
      reason,
      errorCode: '',
      errorMessage: ''
    };

  } catch (error) {
    console.error(
      'Mock unsuccessful finalisation error:',
      error
    );

    return {
      success: false,
      outcome: '',
      appointment_type: '',
      reason: '',
      errorCode: 'ERROR_999',
      errorMessage: 'Unexpected error'
    };
  }
};